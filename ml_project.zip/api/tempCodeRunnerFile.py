
    file: UploadFile = File(...)